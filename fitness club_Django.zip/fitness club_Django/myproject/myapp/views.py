from django.shortcuts import redirect, render
from django.http import HttpResponse
from myapp.models import userdata

def login(request):
    return render(request,'login.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')


def registration(request):
    return render(request,'registration.html')

def index(request):
    return render(request,'index.html')

def personal_profile(request):
    return render(request,'personal_profile.html')

def reg(request):
    u=userdata()
    u.name= request.GET['name']
    u.gender= request.GET['gender']
    u.email= request.GET['email']
    u.dob= request.GET['dob']
    u.membership= request.GET['membership']
    u.user_type= request.GET['user_type']
    u.country= request.GET['country']
    u.contact= request.GET['contact']
    u.password= request.GET['password']
    u.save()
    return render(request,'registration.html')

def sign(request):
    a= request.GET['email']
    b= request.GET['password']
    if userdata.objects.filter(email=a,password=b):
        return render(request,'index.html')
    else:
        return redirect('../login')
    
def display(request):
    a= userdata.objects.all()
    return render(request,'display.html',{'userdata':a})

def delete(request,id):
    e=userdata.objects.get(id=id)
    e.delete()
    return  redirect('../display')

def editdata(request,id):
    d=userdata.objects.get(id=id)
    return render(request,'editdata.html',{'x':d})

def edit(request,id):
    d=userdata.objects.get(id=id)
    d.name=request.GET['a1']
    d.gender=request.GET['a2']
    d.email=request.GET['a3']
    d.dob=request.GET['a4']
    d.membership=request.GET['a5']
    d.user_type=request.GET['a6']
    d.country=request.GET['a7']
    d.contact=request.GET['a8']
    d.password=request.GET['a9']
    d.save()
    return redirect('../display')

# Create your views here.
