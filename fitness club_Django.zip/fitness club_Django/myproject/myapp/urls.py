from django.urls import path
from . import views
urlpatterns=[
    path('index',views.index),
    path('contact',views.contact),
    path('about',views.about),
    path('registration',views.registration),
    path('login',views.login),
    path('personal_profile',views.personal_profile),
    path('reg',views.reg),
    path('sign',views.sign),
    path('display',views.display),
    path('del/<int:id>',views.delete),
    path('editdata/<int:id>',views.editdata),
    path('edit/<int:id>',views.edit),
]