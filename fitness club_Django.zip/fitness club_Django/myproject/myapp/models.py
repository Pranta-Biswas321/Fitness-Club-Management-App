from django.db import models

# Create your models here.
class userdata(models.Model):
    name= models.CharField(max_length=100)
    gender= models.CharField(max_length=20)
    email= models.EmailField()
    dob= models.DateField(max_length=100)
    membership= models.CharField(max_length=20)
    user_type= models.CharField(max_length=20)
    country= models.CharField(max_length=50)
    contact= models.IntegerField()
    password= models.CharField(max_length=100)

class Meta:
    db_table="userdata"